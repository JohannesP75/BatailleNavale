﻿/// <summary>
/// Encapsule l'état du bateau (intact, touché et coulé)
/// </summary>
public enum ShipState
{
    ShipIntact,
    ShipTouched,
    ShipBlowed,
    //BATEAU_NBRE_ETATS
}